package com.example.walpurisnacht.jestion;

import java.util.ArrayList;

/**
 * Created by walpurisnacht on 15/11/2015.
 */
public class Feature {
    public float
            Mean,
            StdDev,
            Max,
            Min,
            Mad,
            Med,
            Skew;

    public ArrayList<Float> retFloat() {
        ArrayList<Float> ret = new ArrayList<>();

        ret.add(Max);
        ret.add(Min);
        ret.add(Mean);
        ret.add(StdDev);
        ret.add(Med);
        ret.add(Mad);
        ret.add(Skew);

        return ret;
    }
}
